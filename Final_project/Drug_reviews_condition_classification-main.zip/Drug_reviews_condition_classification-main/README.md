# Drug_reviews_condition_classification



After cloning this git repo download the dataset from [here](https://archive.ics.uci.edu/ml/datasets/Drug+Review+Dataset+%28Drugs.com%29) and model from [here](https://drive.google.com/drive/folders/1sCnPnXdAaJe4UaxReygzAULsZJWnzKZT?usp=sharing) and place them on Data and Model folders respectively.
